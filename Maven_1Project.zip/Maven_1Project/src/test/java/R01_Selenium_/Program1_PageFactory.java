package R01_Selenium_;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Program1_PageFactory {

	public static void main(String[] args) {
	
		
//		@FindBy (id="")
//		WebElement txtun;
//		
		
		
		
		
	

	}

}
